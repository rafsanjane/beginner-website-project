<div class="d-none" id="loading-div">
    <div id="spinner-container">
        <div id="loading-spinner"></div>
    </div>
</div>

@extends('app')
@section('content')
    @include('components.hero')
    @include('components.about')
@endsection

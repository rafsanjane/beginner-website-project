@extends('app')
@section('content')
    @include('components.contact-form')
@endsection


<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-8 mx-auto text-center mb-5">
                <span class="text-muted">Lorem Ipsum</span>
                <h2 class="display-5 fw-bold mt-2 mb-3">Lorem ipsum dolor sit amet consectutar domor at elis</h2>
                <p class="lead text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque massa nibh, pulvinar vitae aliquet nec, accumsan aliquet orci.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-md-6 col-lg-4 mb-4">
                <div class="d-flex justify-content-center align-items-center py-5 bg-light rounded">
                    <div class="text-center">
                        <img class="mx-auto mb-5 img-fluid" src="{{asset('bootstrap5-plain-assets/images/blue-400-avatar.png')}}" alt="" style="width: 80px;height: 80px">
                        <h4 class="fw-bold">Danny Bailey</h4>
                        <p class="text-muted">CEO &amp; Founder</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4 mb-4">
                <div class="d-flex justify-content-center align-items-center py-5 bg-light rounded">
                    <div class="text-center">
                        <img class="mx-auto mb-5 img-fluid" src="{{asset('bootstrap5-plain-assets/images/blue-400-avatar.png')}}" alt="" style="width: 80px;height: 80px">
                        <h4 class="fw-bold">Danny Bailey</h4>
                        <p class="text-muted">CEO &amp; Founder</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4 mb-4">
                <div class="d-flex justify-content-center align-items-center py-5 bg-light rounded">
                    <div class="text-center">
                        <img class="mx-auto mb-5 img-fluid" src="{{asset('bootstrap5-plain-assets/images/blue-400-avatar.png')}}" alt="" style="width: 80px;height: 80px">
                        <h4 class="fw-bold">Danny Bailey</h4>
                        <p class="text-muted">CEO &amp; Founder</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4 mb-4 mb-lg-0">
                <div class="d-flex justify-content-center align-items-center py-5 bg-light rounded">
                    <div class="text-center">
                        <img class="mx-auto mb-5 img-fluid" src="{{asset('bootstrap5-plain-assets/images/blue-400-avatar.png')}}" alt="" style="width: 80px;height: 80px">
                        <h4 class="fw-bold">Danny Bailey</h4>
                        <p class="text-muted">CEO &amp; Founder</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4 mb-4 mb-md-0">
                <div class="d-flex justify-content-center align-items-center py-5 bg-light rounded">
                    <div class="text-center">
                        <img class="mx-auto mb-5 img-fluid" src="{{asset('bootstrap5-plain-assets/images/blue-400-avatar.png')}}" alt="" style="width: 80px;height: 80px">
                        <h4 class="fw-bold">Danny Bailey</h4>
                        <p class="text-muted">CEO &amp; Founder</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="d-flex justify-content-center align-items-center py-5 bg-light rounded">
                    <div class="text-center">
                        <img class="mx-auto mb-5 img-fluid" src="{{asset('bootstrap5-plain-assets/images/blue-400-avatar.png')}}" alt="" style="width: 80px;height: 80px">
                        <h4 class="fw-bold">Danny Bailey</h4>
                        <p class="text-muted">CEO &amp; Founder</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

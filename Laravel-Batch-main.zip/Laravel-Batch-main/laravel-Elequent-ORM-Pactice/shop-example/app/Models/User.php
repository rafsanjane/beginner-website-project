<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
/**
 * @method static create(string[] $array)
 * @method static updateOrCreate(array $array)
 * @method static where(string $string, int $int)
 */
class User extends Model
{

}
